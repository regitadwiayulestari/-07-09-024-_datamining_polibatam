lokasi_kerja <- "D:/TugasBesar(DM)_Caesar_(07,09,024)"
setwd(lokasi_kerja)
getwd()
install.packages("C50")
install.packages("printr")
library(C50)
library(printr)
dataset <- read.csv("Caesarian.csv", sep=",")
model <- C5.0(Caesarian ~., data=dataset)
model
summary(model)
plot(model)
datatesting <- dataset[,1:5]
predictions <- predict(model, dataset)
table(predictions, dataset$Caesarian)

